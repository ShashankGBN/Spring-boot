package hibernate_demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class ViewDriver
{
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		
		EntityManager manager = factory.createEntityManager();
		
		 Example e = manager.find(Example.class, 1);
		 
		 if(e!=null)
		 {
			 System.out.println(e.getId());
			 System.out.println(e.getName());
		 }
		 else
		 {
			 System.out.println("Id is not present...!");
		 }
	}
}
