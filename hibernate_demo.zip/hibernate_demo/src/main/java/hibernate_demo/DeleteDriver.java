package hibernate_demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DeleteDriver 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		
		EntityManager manager = factory.createEntityManager();
		
		EntityTransaction transaction = manager.getTransaction();
		Example e = manager.find(Example.class, 4);
		
		if(e!=null)
		{
			transaction.begin();
			manager.remove(e);
			System.out.println("deleted successfully...");
			transaction.commit();
		}
		else
		{
			System.out.println("id not present...");
		}
	}
}
