package hibernate_demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import hibernate_demo.Example;

public class ViewAllDriver {

	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
		
		EntityManager manager = factory.createEntityManager();

	    Query q = manager.createQuery("Select s from Example s");
	    
	    List<Example> lt = q.getResultList();
	    
	    for(Example e : lt)
	    {
	    	System.out.println("id : "+e.getId());
	    	System.out.println("name : "+e.getName());
	    }
	}

}
